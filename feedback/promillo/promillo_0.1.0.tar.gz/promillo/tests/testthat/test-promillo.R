library(testthat)

# ------------------------------------------------------------------------------
context("check utilities:")

test_that("get_bodywater works", {
  expect_equal(get_bodywater(sex = "Male", age = 40, height = 180, weight = 85),
    c(2.447, -0.09516, 0.1074, 0.3362) %*% c(1, 40, 180, 85))
  expect_equal(get_bodywater(sex = "Female", age = 40, height = 180, weight = 85),
    c(0.203, -0.07, 0.1069, 0.2466) %*% c(1, 40, 180, 85))
})

test_that("get_alcohol works", {
  drinks <- list(massn = 2, hoibe = 1, wein = 2, schnaps = 1)
  expect_equal(get_alcohol(drinks = drinks), 168)
  # order doesn't matter:
  expect_equal(get_alcohol(drinks = drinks), get_alcohol(drinks = rev(drinks)))
  # vector or list inputs work the same:
  expect_equal(get_alcohol(drinks = drinks),
    get_alcohol(drinks = as.vector(drinks)))
})

test_that("get_permillle works", {
  four_h <- c("2014-10-03 18:00:00", "2014-10-03 22:00:00")
  one_h <- c("2014-10-03 18:00:00", "2014-10-03 19:00:00")
  expect_equal(get_permille(alcohol_drunk = 170, bodywater = 46,
    drinking_time = as.POSIXct(four_h)), 2.352390274057284180742)
  # no reduction in first hour, 0.15/h after that
  expect_equal(get_permille(alcohol_drunk = 170, bodywater = 46,
    drinking_time = as.POSIXct(four_h)),
    get_permille(alcohol_drunk = 170, bodywater = 46,
      drinking_time = as.POSIXct(one_h)) - 3 * 0.15)
  # no negative values if reduction over time > original permille
  expect_true(get_permille(alcohol_drunk = 10, bodywater = 46,
    drinking_time = as.POSIXct(four_h)) == 0)
})

# ------------------------------------------------------------------------------
context("validate input checks:")

test_that("input checks for get_alcohol work", {
  expect_error(get_alcohol(drinks =  NULL), "Assertion on 'names")
  expect_error(get_alcohol(drinks =  2), "Assertion on 'names")
  expect_error(get_alcohol(drinks =  c(tequila = 15)), "Assertion on 'names")
  expect_error(get_alcohol(drinks =  c(hoibe = "2")), "Assertion on 'drinks")
  expect_error(get_alcohol(drinks =  c(hoibe = -2)),  "Assertion on 'drinks")
})

test_that("input checks for get_bodywater work", {
  expect_equal(get_bodywater(sex = "Male", age = 40, height = 180, weight = 85),
    get_bodywater(sex = "M", age = 40, height = 180, weight = 85))
  expect_equal(get_bodywater(sex = "Female", age = 40, height = 180, weight = 85),
    get_bodywater(sex = "F", age = 40, height = 180, weight = 85))

  expect_error(get_bodywater(sex = "Male", age = "40", height = 180, weight = 85),
    "Assertion on 'age' failed")
  expect_error(get_bodywater(sex = "Male", age = 40, height = "180", weight = 85),
    "Assertion on 'height' failed")
  expect_error(get_bodywater(sex = "Male", age = -40, height = 180, weight = 85),
    "Assertion on 'age' failed")
  expect_error(get_bodywater(sex = "Male", age = 40, height = 80, weight = 85),
    "Assertion on 'height' failed")
  expect_error(get_bodywater(sex = "Male", age = 40, height = 180, weight = 20),
    "Assertion on 'weight' failed")
})

test_that("input checks for get_permille work", {
  four_h <- c("2014-10-03 18:00:00", "2014-10-03 22:00:00")
  expect_error(get_permille(alcohol_drunk = 170, bodywater = 46,
    drinking_time = four_h), "Assertion on 'drinking_time' failed")
  # second argument is regular expression, so have to escape "[" with backslashes:
  expect_error(get_permille(alcohol_drunk = 170, bodywater = 46,
    drinking_time = rev(as.POSIXct(four_h))), "drinking_time\\[1\\] <")
})

# ------------------------------------------------------------------------------
context("check user interface:")

test_that("tell_me_how_drunk behaves", {
  four_h <- c("2014-10-03 18:00:00", "2014-10-03 22:00:00")
  drinks <- list(massn = 2, hoibe = 1, wein = 2, schnaps = 1)
  expect_warning(tell_me_how_drunk(age = 99, sex = "M", height = 180, weight = 85,
    drinking_time = as.POSIXct(four_h), drinks = drinks))
  expect_equal(tell_me_how_drunk(age = 40, sex = "M", height = 180, weight = 85,
    drinking_time = as.POSIXct(four_h), drinks = drinks),
    2.286723085244774440892)
})
