#' Grafische Darstellung der BAK über die Zeit
#'
#' Diese Funktion plottet den geschätzten Verlauf der BAK über die Zeit in 5
#' Minuten Abständen. Natürlich völliger Blödsinn weil hier davon
#' ausgegangen wird dass sich jemand alle Drinks auf einmal zum Zeitpunkt
#' `drinking_time[1]` reinschüttet und dann nach 1h langsam anfängt den
#' Alkohol abzubauen....
#'
#' @inheritParams tell_me_how_drunk
#' @return zeichnet den Plot und gibt das geplottete `ggplot`-Objekt zurück.
#' @encoding UTF-8
#' @export
#' @seealso \code{\link{tell_me_how_drunk}}
#' @importFrom ggplot2 qplot theme_minimal
#' @examples
#'  show_me_how_drunk(age = 25, sex = "F", height = 170, weight = 85,
#'    drinking_time = as.POSIXct(c("2014-10-03 20:00:00", "2014-10-04 03:00:00")),
#'    drinks = c(schnaps = 5, hoibe = 3))
show_me_how_drunk <- function(age, sex = c("Male", "Female"), height, weight,
  drinking_time, drinks) {

  stopifnot(inherits(drinking_time, "POSIXt"),
    drinking_time[1] < drinking_time[2])
  time_seq <- seq(drinking_time[1], drinking_time[2], by = "5 min")[-1]
  if (length(time_seq) < 2) {
    stop("time interval given by drinking_time is too short to plot anything.")
  }

  # very inefficient -- recomputes GKW each time. we don't care, it's cheap to
  # do & premature optimization is the root of all evil....
  get_permille_timecourse <- function(time) {
    # impure function -- ok because we define it inside another function whose
    # arguments we are using implicitly, so we can rely on these implicit args
    # to be available for get_permille_timecourse...
    tell_me_how_drunk(age = age, sex = sex, height = height, weight = weight,
      drinking_time = c(drinking_time[1], time), drinks = drinks)
  }
  data <- data.frame(time = time_seq,
    permille = vapply(X = time_seq, FUN = get_permille_timecourse,
      FUN.VALUE = numeric(1)))
  # use "with()"-hack to avoid "undefined global vars"-NOTEs,
  # see https://stackoverflow.com/q/9439256/295025 discussion
  with(data,
    qplot(x = time, y = permille, geom = "line", data = data) + theme_minimal())
}
